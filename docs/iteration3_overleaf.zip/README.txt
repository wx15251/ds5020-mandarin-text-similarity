Compile main.tex with XeLaTeX. Generated from the public project source.
